import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";

const root = process.cwd();
const template = await readFile(join(root, "site", "index.html"), "utf8");
const css = await readFile(join(root, "site", "styles.css"), "utf8");
const js = await readFile(join(root, "site", "app.js"), "utf8");

const standalone = template
  .replace('<link rel="stylesheet" href="/styles.css" />', `<style>${css}</style>`)
  .replace('<script type="module" src="/app.js"></script>', `<script>${js}</script>`)
  .replace('<meta property="og:image" content="/og.png" />', "");

await writeFile(join(root, "index.html"), standalone);
console.log("Built standalone index.html");
