import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

const root = process.cwd();
const dist = join(root, "dist");
await rm(dist, { recursive: true, force: true });
await mkdir(join(dist, ".openai"), { recursive: true });
await mkdir(join(dist, "server"), { recursive: true });
await cp(join(root, "site"), dist, { recursive: true });
await cp(join(root, ".openai", "hosting.json"), join(dist, ".openai", "hosting.json"));

const html = await readFile(join(root, "site", "index.html"), "utf8");
const css = await readFile(join(root, "site", "styles.css"), "utf8");
const js = await readFile(join(root, "site", "app.js"), "utf8");
const og = (await readFile(join(root, "site", "og.png"))).toString("base64");
const worker = `const files = ${JSON.stringify({ "/": [html, "text/html; charset=utf-8"], "/index.html": [html, "text/html; charset=utf-8"], "/styles.css": [css, "text/css; charset=utf-8"], "/app.js": [js, "text/javascript; charset=utf-8"] })};
const og = "${og}";
export default { async fetch(request) { const url = new URL(request.url); if (url.pathname === "/og.png") { const bytes = Uint8Array.from(atob(og), c => c.charCodeAt(0)); return new Response(bytes, { headers: { "content-type": "image/png", "cache-control": "public, max-age=86400" } }); } const item = files[url.pathname] || files["/"]; return new Response(item[0], { headers: { "content-type": item[1], "cache-control": url.pathname === "/" ? "no-cache" : "public, max-age=3600", "x-content-type-options": "nosniff" } }); } };`;
await writeFile(join(dist, "_worker.js"), worker);
await writeFile(join(dist, "server", "index.js"), worker);
console.log("Built Dubai Property Pay Tracker");
